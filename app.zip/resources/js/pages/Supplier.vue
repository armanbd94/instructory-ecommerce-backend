<template>
  <div><h1>Supplier</h1></div>
</template>

<script>
export default {
    name:'Supplier'
}
</script>

<style>

</style>