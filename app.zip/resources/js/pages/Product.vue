<template>
  <div><h1>Product</h1></div>
</template>

<script>
export default {
    name:'Product'
}
</script>

<style>

</style>