<template>
  <div><h1>Brand</h1></div>
</template>

<script>
export default {
    name:'Brand'
}
</script>

<style>

</style>