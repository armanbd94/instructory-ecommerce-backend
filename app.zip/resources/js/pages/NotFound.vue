<template>
  <div><h1>NotFound</h1></div>
</template>

<script>
export default {
    name:'NotFound'
}
</script>

<style>

</style>